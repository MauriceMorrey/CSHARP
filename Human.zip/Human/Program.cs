﻿using System;

namespace Human
{
    public class Human
    {
        public string name;
        public int strength = 3;
        public int intelligence = 100;
        public int dexterity = 100;
        public int health = 100; 

        public Human(string name)
        {
            this.name = name;
            strength = 3;
            intelligence = 3;
            dexterity = 3;
            health = 100;
        }
        public Human(string name, int strength, int intelligence, int dexterity, int health)
        {
           this.name = name;
            this.strength = strength;
            this.intelligence = intelligence;
            this.dexterity = dexterity;
            this.health = health; 
        }
        public void attack(object Enemy)
        {
            if(Enemy is Human)
            {
                Human target = Enemy as Human;
                target.health -= strength*5;
                // System.Console.WriteLine(health);
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
